--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 14.5

-- Started on 2022-08-28 23:48:33

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 241 (class 1255 OID 24850)
-- Name: zam(double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.zam(ucret double precision) RETURNS integer
    LANGUAGE plpgsql
    AS $$
	 DECLARE BEGIN
	 if ucret=400 then
	 return ucret+50;
	 end if;
	END; 
	$$;


ALTER FUNCTION public.zam(ucret double precision) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 209 (class 1259 OID 24851)
-- Name: Adres; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Adres" (
    id integer NOT NULL,
    il text NOT NULL,
    ilce text NOT NULL,
    aciklama text NOT NULL
);


ALTER TABLE public."Adres" OWNER TO postgres;

--
-- TOC entry 210 (class 1259 OID 24856)
-- Name: Adres_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Adres" ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Adres_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 211 (class 1259 OID 24857)
-- Name: Araba; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Araba" (
    id integer NOT NULL,
    marka text NOT NULL,
    plaka text NOT NULL,
    model text NOT NULL,
    "modelYil" integer NOT NULL,
    yakit text NOT NULL,
    renk text NOT NULL,
    "ruhsatNo" text NOT NULL,
    "kiraFiyat" double precision
);


ALTER TABLE public."Araba" OWNER TO postgres;

--
-- TOC entry 212 (class 1259 OID 24862)
-- Name: Araba_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Araba" ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Araba_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 213 (class 1259 OID 24863)
-- Name: Ceza; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Ceza" (
    id integer NOT NULL,
    "kiralamaId" integer NOT NULL,
    "odemeTarih" date,
    tip text NOT NULL,
    "cezaNo" text NOT NULL,
    "sonOdemeTarih" date NOT NULL,
    ucret double precision
);


ALTER TABLE public."Ceza" OWNER TO postgres;

--
-- TOC entry 214 (class 1259 OID 24868)
-- Name: Ceza_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Ceza" ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Ceza_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 215 (class 1259 OID 24869)
-- Name: Fatura; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Fatura" (
    id integer NOT NULL,
    ucret double precision NOT NULL,
    tarih text NOT NULL,
    "kiralamaId" integer NOT NULL,
    "vergiMiktar" double precision NOT NULL,
    "odemeTipId" integer NOT NULL
);


ALTER TABLE public."Fatura" OWNER TO postgres;

--
-- TOC entry 216 (class 1259 OID 24874)
-- Name: Fatura_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Fatura" ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Fatura_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 217 (class 1259 OID 24875)
-- Name: Filo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Filo" (
    id integer NOT NULL,
    "musaitlikDurumu" boolean NOT NULL,
    "arabaId" integer NOT NULL
);


ALTER TABLE public."Filo" OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 24878)
-- Name: Filo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Filo" ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Filo_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 219 (class 1259 OID 24879)
-- Name: Kiralama; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Kiralama" (
    id integer NOT NULL,
    "musteriId" integer NOT NULL,
    "arabaId" integer NOT NULL,
    "PersonalId" integer NOT NULL,
    "alisTarih" date NOT NULL,
    "iadeTarih" date,
    sure integer
);


ALTER TABLE public."Kiralama" OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 24882)
-- Name: Kiralama_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Kiralama" ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Kiralama_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 221 (class 1259 OID 24883)
-- Name: OdemeTipi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."OdemeTipi" (
    id integer NOT NULL,
    tur text NOT NULL,
    "indrimOrani" double precision NOT NULL
);


ALTER TABLE public."OdemeTipi" OWNER TO postgres;

--
-- TOC entry 222 (class 1259 OID 24888)
-- Name: OdemeTipi_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."OdemeTipi" ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."OdemeTipi_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 223 (class 1259 OID 24889)
-- Name: arabaOzellikler; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."arabaOzellikler" (
    "id " integer NOT NULL,
    "arabaId" integer NOT NULL,
    kilometre bigint NOT NULL,
    aciklama text
);


ALTER TABLE public."arabaOzellikler" OWNER TO postgres;

--
-- TOC entry 224 (class 1259 OID 24894)
-- Name: Ozellikler_id _seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."arabaOzellikler" ALTER COLUMN "id " ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Ozellikler_id _seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 225 (class 1259 OID 24895)
-- Name: Personal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Personal" (
    id integer NOT NULL,
    "subeId" integer NOT NULL,
    "kisiId" integer NOT NULL,
    password text NOT NULL
);


ALTER TABLE public."Personal" OWNER TO postgres;

--
-- TOC entry 226 (class 1259 OID 24900)
-- Name: Personal_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Personal" ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Personal_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 227 (class 1259 OID 24901)
-- Name: Servis_Firmasi ; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Servis_Firmasi " (
    id integer NOT NULL,
    ad text NOT NULL,
    "telefonNo" text NOT NULL,
    "adresId" integer NOT NULL,
    "vergiNo" text NOT NULL,
    email text
);


ALTER TABLE public."Servis_Firmasi " OWNER TO postgres;

--
-- TOC entry 228 (class 1259 OID 24906)
-- Name: Servis_Firmasi _id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Servis_Firmasi " ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Servis_Firmasi _id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 229 (class 1259 OID 24907)
-- Name: Servis_Gecmis; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Servis_Gecmis" (
    id integer NOT NULL,
    "firmaId" integer NOT NULL,
    "arabaId" integer NOT NULL,
    "verilisTarih" date NOT NULL,
    "teslimTarih" date,
    ucret double precision,
    aciklama text
);


ALTER TABLE public."Servis_Gecmis" OWNER TO postgres;

--
-- TOC entry 230 (class 1259 OID 24912)
-- Name: Servis_Gecmis_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Servis_Gecmis" ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Servis_Gecmis_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 231 (class 1259 OID 24913)
-- Name: Sigorta_Firma; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Sigorta_Firma" (
    id integer NOT NULL,
    ad text NOT NULL,
    "telefonNo" text NOT NULL,
    "adresId" integer NOT NULL,
    email text NOT NULL
);


ALTER TABLE public."Sigorta_Firma" OWNER TO postgres;

--
-- TOC entry 232 (class 1259 OID 24918)
-- Name: Sigorta_Firma_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Sigorta_Firma" ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Sigorta_Firma_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 233 (class 1259 OID 24919)
-- Name: Sigorta_Police; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Sigorta_Police" (
    id integer NOT NULL,
    tur text NOT NULL,
    "baslangicTarih" date NOT NULL,
    "bitisTarih" date NOT NULL,
    "arabaId" integer NOT NULL,
    "sigortaFirmaId" integer NOT NULL,
    "policeNo" text NOT NULL,
    prim double precision NOT NULL
);


ALTER TABLE public."Sigorta_Police" OWNER TO postgres;

--
-- TOC entry 234 (class 1259 OID 24924)
-- Name: Sigorta_Police_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Sigorta_Police" ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Sigorta_Police_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 235 (class 1259 OID 24925)
-- Name: Sube; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Sube" (
    id integer NOT NULL,
    "adresId" integer NOT NULL,
    "telefonNo" text
);


ALTER TABLE public."Sube" OWNER TO postgres;

--
-- TOC entry 236 (class 1259 OID 24930)
-- Name: Sube_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Sube" ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Sube_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 237 (class 1259 OID 24931)
-- Name: kisi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kisi (
    id integer NOT NULL,
    ad text NOT NULL,
    soyad text NOT NULL,
    "TC" text NOT NULL,
    "telefonNo" text NOT NULL,
    email text NOT NULL,
    cinsiyet character(1) NOT NULL,
    "dogumTarih" date NOT NULL,
    "adresId" integer NOT NULL
);


ALTER TABLE public.kisi OWNER TO postgres;

--
-- TOC entry 238 (class 1259 OID 24936)
-- Name: kisi_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.kisi ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.kisi_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 239 (class 1259 OID 24937)
-- Name: musteri; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.musteri (
    id integer NOT NULL,
    meslek text NOT NULL,
    "kisiId" integer NOT NULL
);


ALTER TABLE public.musteri OWNER TO postgres;

--
-- TOC entry 240 (class 1259 OID 24942)
-- Name: musteri_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.musteri ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.musteri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 3474 (class 0 OID 24851)
-- Dependencies: 209
-- Data for Name: Adres; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Adres" (id, il, ilce, aciklama) OVERRIDING SYSTEM VALUE VALUES (1, 'sakarya', 'serdivan', 'univrsite Cad.');
INSERT INTO public."Adres" (id, il, ilce, aciklama) OVERRIDING SYSTEM VALUE VALUES (8, 'Sakarya', 'adapazari', 'adapazari');
INSERT INTO public."Adres" (id, il, ilce, aciklama) OVERRIDING SYSTEM VALUE VALUES (9, 'Sakarya', 'adapazari', '1 sk');
INSERT INTO public."Adres" (id, il, ilce, aciklama) OVERRIDING SYSTEM VALUE VALUES (10, 'Sakarya', 'adapazari', '2 sk');
INSERT INTO public."Adres" (id, il, ilce, aciklama) OVERRIDING SYSTEM VALUE VALUES (11, 'Sakarya', 'adapazari', '3 sk');
INSERT INTO public."Adres" (id, il, ilce, aciklama) OVERRIDING SYSTEM VALUE VALUES (12, 'Sakarya', 'erenler', '4 sk');


--
-- TOC entry 3476 (class 0 OID 24857)
-- Dependencies: 211
-- Data for Name: Araba; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Araba" (id, marka, plaka, model, "modelYil", yakit, renk, "ruhsatNo", "kiraFiyat") OVERRIDING SYSTEM VALUE VALUES (1, 'toyota', '1254', 'camry', 2020, 'dizal', 'beyaz', '846512', 400);
INSERT INTO public."Araba" (id, marka, plaka, model, "modelYil", yakit, renk, "ruhsatNo", "kiraFiyat") OVERRIDING SYSTEM VALUE VALUES (2, 'toyota', '1564', 'camry', 2020, 'dizal', 'beyaz', '894988', 400);
INSERT INTO public."Araba" (id, marka, plaka, model, "modelYil", yakit, renk, "ruhsatNo", "kiraFiyat") OVERRIDING SYSTEM VALUE VALUES (3, 'toyota', '7412', 'camry', 2020, 'dizal', 'siyah', '541652', 500);
INSERT INTO public."Araba" (id, marka, plaka, model, "modelYil", yakit, renk, "ruhsatNo", "kiraFiyat") OVERRIDING SYSTEM VALUE VALUES (4, 'toyota', '9874', 'camry', 2023, 'benzin', 'siyah', '978456', 400);
INSERT INTO public."Araba" (id, marka, plaka, model, "modelYil", yakit, renk, "ruhsatNo", "kiraFiyat") OVERRIDING SYSTEM VALUE VALUES (5, 'toyota', '9844', 'corola', 2022, 'dizal', 'beyaz', '498851', 500);
INSERT INTO public."Araba" (id, marka, plaka, model, "modelYil", yakit, renk, "ruhsatNo", "kiraFiyat") OVERRIDING SYSTEM VALUE VALUES (6, 'honda', '4871', 'civic', 2020, 'dizal', 'beyaz', '5486', 300);
INSERT INTO public."Araba" (id, marka, plaka, model, "modelYil", yakit, renk, "ruhsatNo", "kiraFiyat") OVERRIDING SYSTEM VALUE VALUES (7, 'honda', '98742', 'civic', 2022, 'benzin', 'beyaz', '84915', 400);
INSERT INTO public."Araba" (id, marka, plaka, model, "modelYil", yakit, renk, "ruhsatNo", "kiraFiyat") OVERRIDING SYSTEM VALUE VALUES (8, 'fiat', '3652', 'doblo', 2020, 'dizal', 'beyaz', '6532', 300);
INSERT INTO public."Araba" (id, marka, plaka, model, "modelYil", yakit, renk, "ruhsatNo", "kiraFiyat") OVERRIDING SYSTEM VALUE VALUES (10, 'tofaş', '45636', 'şahin', 1988, 'dizal', 'kirmizi', '65432', 100);
INSERT INTO public."Araba" (id, marka, plaka, model, "modelYil", yakit, renk, "ruhsatNo", "kiraFiyat") OVERRIDING SYSTEM VALUE VALUES (9, 'tesla', '011', 'X', 2022, 'elektrik', 'beyaz', '8654312', 2000);


--
-- TOC entry 3478 (class 0 OID 24863)
-- Dependencies: 213
-- Data for Name: Ceza; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Ceza" (id, "kiralamaId", "odemeTarih", tip, "cezaNo", "sonOdemeTarih", ucret) OVERRIDING SYSTEM VALUE VALUES (1, 3, NULL, 'hiz', '654', '2022-09-15', 200);


--
-- TOC entry 3480 (class 0 OID 24869)
-- Dependencies: 215
-- Data for Name: Fatura; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Fatura" (id, ucret, tarih, "kiralamaId", "vergiMiktar", "odemeTipId") OVERRIDING SYSTEM VALUE VALUES (1, 500, '2022-08-25', 4, 20, 1);


--
-- TOC entry 3482 (class 0 OID 24875)
-- Dependencies: 217
-- Data for Name: Filo; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Filo" (id, "musaitlikDurumu", "arabaId") OVERRIDING SYSTEM VALUE VALUES (1, true, 8);
INSERT INTO public."Filo" (id, "musaitlikDurumu", "arabaId") OVERRIDING SYSTEM VALUE VALUES (2, false, 1);
INSERT INTO public."Filo" (id, "musaitlikDurumu", "arabaId") OVERRIDING SYSTEM VALUE VALUES (3, true, 9);
INSERT INTO public."Filo" (id, "musaitlikDurumu", "arabaId") OVERRIDING SYSTEM VALUE VALUES (4, true, 10);


--
-- TOC entry 3484 (class 0 OID 24879)
-- Dependencies: 219
-- Data for Name: Kiralama; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Kiralama" (id, "musteriId", "arabaId", "PersonalId", "alisTarih", "iadeTarih", sure) OVERRIDING SYSTEM VALUE VALUES (3, 1, 1, 1, '2022-08-25', '2022-08-30', NULL);
INSERT INTO public."Kiralama" (id, "musteriId", "arabaId", "PersonalId", "alisTarih", "iadeTarih", sure) OVERRIDING SYSTEM VALUE VALUES (4, 1, 2, 1, '2022-07-01', '2022-07-30', NULL);
INSERT INTO public."Kiralama" (id, "musteriId", "arabaId", "PersonalId", "alisTarih", "iadeTarih", sure) OVERRIDING SYSTEM VALUE VALUES (5, 2, 6, 1, '2022-07-01', '2022-07-30', NULL);
INSERT INTO public."Kiralama" (id, "musteriId", "arabaId", "PersonalId", "alisTarih", "iadeTarih", sure) OVERRIDING SYSTEM VALUE VALUES (6, 2, 4, 1, '2022-08-01', '2022-08-30', NULL);
INSERT INTO public."Kiralama" (id, "musteriId", "arabaId", "PersonalId", "alisTarih", "iadeTarih", sure) OVERRIDING SYSTEM VALUE VALUES (7, 1, 3, 1, '2022-07-31', '2022-09-30', NULL);


--
-- TOC entry 3486 (class 0 OID 24883)
-- Dependencies: 221
-- Data for Name: OdemeTipi; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."OdemeTipi" (id, tur, "indrimOrani") OVERRIDING SYSTEM VALUE VALUES (1, 'nakit', 0);
INSERT INTO public."OdemeTipi" (id, tur, "indrimOrani") OVERRIDING SYSTEM VALUE VALUES (2, 'kredikart', 0);
INSERT INTO public."OdemeTipi" (id, tur, "indrimOrani") OVERRIDING SYSTEM VALUE VALUES (3, 'havale', 0);
INSERT INTO public."OdemeTipi" (id, tur, "indrimOrani") OVERRIDING SYSTEM VALUE VALUES (4, 'taksit', 0);


--
-- TOC entry 3490 (class 0 OID 24895)
-- Dependencies: 225
-- Data for Name: Personal; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Personal" (id, "subeId", "kisiId", password) OVERRIDING SYSTEM VALUE VALUES (1, 1, 1, '123');


--
-- TOC entry 3492 (class 0 OID 24901)
-- Dependencies: 227
-- Data for Name: Servis_Firmasi ; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Servis_Firmasi " (id, ad, "telefonNo", "adresId", "vergiNo", email) OVERRIDING SYSTEM VALUE VALUES (1, 'hamoo', '05545', 10, '15648', NULL);
INSERT INTO public."Servis_Firmasi " (id, ad, "telefonNo", "adresId", "vergiNo", email) OVERRIDING SYSTEM VALUE VALUES (2, 'tamir', '05554', 11, '65489', 'ds@00');


--
-- TOC entry 3494 (class 0 OID 24907)
-- Dependencies: 229
-- Data for Name: Servis_Gecmis; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Servis_Gecmis" (id, "firmaId", "arabaId", "verilisTarih", "teslimTarih", ucret, aciklama) OVERRIDING SYSTEM VALUE VALUES (1, 1, 5, '2022-08-10', NULL, NULL, NULL);
INSERT INTO public."Servis_Gecmis" (id, "firmaId", "arabaId", "verilisTarih", "teslimTarih", ucret, aciklama) OVERRIDING SYSTEM VALUE VALUES (2, 2, 2, '2022-08-15', NULL, NULL, NULL);


--
-- TOC entry 3496 (class 0 OID 24913)
-- Dependencies: 231
-- Data for Name: Sigorta_Firma; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Sigorta_Firma" (id, ad, "telefonNo", "adresId", email) OVERRIDING SYSTEM VALUE VALUES (1, 'ankara', '05655', 11, '@00');


--
-- TOC entry 3498 (class 0 OID 24919)
-- Dependencies: 233
-- Data for Name: Sigorta_Police; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Sigorta_Police" (id, tur, "baslangicTarih", "bitisTarih", "arabaId", "sigortaFirmaId", "policeNo", prim) OVERRIDING SYSTEM VALUE VALUES (1, 'kasko', '2022-08-01', '2023-08-01', 7, 1, '15346', 15);


--
-- TOC entry 3500 (class 0 OID 24925)
-- Dependencies: 235
-- Data for Name: Sube; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Sube" (id, "adresId", "telefonNo") OVERRIDING SYSTEM VALUE VALUES (1, 1, '55555');


--
-- TOC entry 3488 (class 0 OID 24889)
-- Dependencies: 223
-- Data for Name: arabaOzellikler; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."arabaOzellikler" ("id ", "arabaId", kilometre, aciklama) OVERRIDING SYSTEM VALUE VALUES (1, 1, 5000, 'temizzzz');


--
-- TOC entry 3502 (class 0 OID 24931)
-- Dependencies: 237
-- Data for Name: kisi; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.kisi (id, ad, soyad, "TC", "telefonNo", email, cinsiyet, "dogumTarih", "adresId") OVERRIDING SYSTEM VALUE VALUES (1, 'arshad', 'amir monsur', '999', '55111', 'arshad@00', 'e', '1995-02-14', 1);
INSERT INTO public.kisi (id, ad, soyad, "TC", "telefonNo", email, cinsiyet, "dogumTarih", "adresId") OVERRIDING SYSTEM VALUE VALUES (3, 'ahmed', 't.', '8512', '55111', 'arshad@00', 'e', '1995-02-14', 8);
INSERT INTO public.kisi (id, ad, soyad, "TC", "telefonNo", email, cinsiyet, "dogumTarih", "adresId") OVERRIDING SYSTEM VALUE VALUES (4, 'yosuf', 'y', '84512', '55111', 'arshad@00', 'e', '1995-02-14', 9);


--
-- TOC entry 3504 (class 0 OID 24937)
-- Dependencies: 239
-- Data for Name: musteri; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.musteri (id, meslek, "kisiId") OVERRIDING SYSTEM VALUE VALUES (1, 'ogrenci', 3);
INSERT INTO public.musteri (id, meslek, "kisiId") OVERRIDING SYSTEM VALUE VALUES (2, 'ogrenci', 4);


--
-- TOC entry 3511 (class 0 OID 0)
-- Dependencies: 210
-- Name: Adres_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Adres_id_seq"', 12, true);


--
-- TOC entry 3512 (class 0 OID 0)
-- Dependencies: 212
-- Name: Araba_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Araba_id_seq"', 10, true);


--
-- TOC entry 3513 (class 0 OID 0)
-- Dependencies: 214
-- Name: Ceza_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Ceza_id_seq"', 2, true);


--
-- TOC entry 3514 (class 0 OID 0)
-- Dependencies: 216
-- Name: Fatura_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Fatura_id_seq"', 1, true);


--
-- TOC entry 3515 (class 0 OID 0)
-- Dependencies: 218
-- Name: Filo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Filo_id_seq"', 4, true);


--
-- TOC entry 3516 (class 0 OID 0)
-- Dependencies: 220
-- Name: Kiralama_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Kiralama_id_seq"', 7, true);


--
-- TOC entry 3517 (class 0 OID 0)
-- Dependencies: 222
-- Name: OdemeTipi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."OdemeTipi_id_seq"', 4, true);


--
-- TOC entry 3518 (class 0 OID 0)
-- Dependencies: 224
-- Name: Ozellikler_id _seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Ozellikler_id _seq"', 1, true);


--
-- TOC entry 3519 (class 0 OID 0)
-- Dependencies: 226
-- Name: Personal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Personal_id_seq"', 1, true);


--
-- TOC entry 3520 (class 0 OID 0)
-- Dependencies: 228
-- Name: Servis_Firmasi _id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Servis_Firmasi _id_seq"', 2, true);


--
-- TOC entry 3521 (class 0 OID 0)
-- Dependencies: 230
-- Name: Servis_Gecmis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Servis_Gecmis_id_seq"', 2, true);


--
-- TOC entry 3522 (class 0 OID 0)
-- Dependencies: 232
-- Name: Sigorta_Firma_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Sigorta_Firma_id_seq"', 1, true);


--
-- TOC entry 3523 (class 0 OID 0)
-- Dependencies: 234
-- Name: Sigorta_Police_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Sigorta_Police_id_seq"', 1, true);


--
-- TOC entry 3524 (class 0 OID 0)
-- Dependencies: 236
-- Name: Sube_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Sube_id_seq"', 1, true);


--
-- TOC entry 3525 (class 0 OID 0)
-- Dependencies: 238
-- Name: kisi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.kisi_id_seq', 4, true);


--
-- TOC entry 3526 (class 0 OID 0)
-- Dependencies: 240
-- Name: musteri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.musteri_id_seq', 2, true);


--
-- TOC entry 3241 (class 2606 OID 24944)
-- Name: Adres Adres_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Adres"
    ADD CONSTRAINT "Adres_pkey" PRIMARY KEY (id);


--
-- TOC entry 3245 (class 2606 OID 24946)
-- Name: Araba Araba_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Araba"
    ADD CONSTRAINT "Araba_pkey" PRIMARY KEY (id);


--
-- TOC entry 3247 (class 2606 OID 24948)
-- Name: Araba Araba_plaka_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Araba"
    ADD CONSTRAINT "Araba_plaka_key" UNIQUE (plaka);


--
-- TOC entry 3249 (class 2606 OID 24950)
-- Name: Araba Araba_ruhsatNo_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Araba"
    ADD CONSTRAINT "Araba_ruhsatNo_key" UNIQUE ("ruhsatNo");


--
-- TOC entry 3253 (class 2606 OID 24952)
-- Name: Ceza Ceza_cezaNo_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ceza"
    ADD CONSTRAINT "Ceza_cezaNo_key" UNIQUE ("cezaNo");


--
-- TOC entry 3255 (class 2606 OID 24954)
-- Name: Ceza Ceza_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ceza"
    ADD CONSTRAINT "Ceza_pkey" PRIMARY KEY (id);


--
-- TOC entry 3259 (class 2606 OID 24956)
-- Name: Fatura Fatura_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Fatura"
    ADD CONSTRAINT "Fatura_pkey" PRIMARY KEY (id);


--
-- TOC entry 3263 (class 2606 OID 24958)
-- Name: Filo Filo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Filo"
    ADD CONSTRAINT "Filo_pkey" PRIMARY KEY (id);


--
-- TOC entry 3267 (class 2606 OID 24960)
-- Name: Kiralama Kiralama_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Kiralama"
    ADD CONSTRAINT "Kiralama_pkey" PRIMARY KEY (id);


--
-- TOC entry 3271 (class 2606 OID 24962)
-- Name: OdemeTipi OdemeTipi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OdemeTipi"
    ADD CONSTRAINT "OdemeTipi_pkey" PRIMARY KEY (id);


--
-- TOC entry 3275 (class 2606 OID 24964)
-- Name: arabaOzellikler Ozellikler_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."arabaOzellikler"
    ADD CONSTRAINT "Ozellikler_pkey" PRIMARY KEY ("id ");


--
-- TOC entry 3279 (class 2606 OID 24966)
-- Name: Personal Personal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Personal"
    ADD CONSTRAINT "Personal_pkey" PRIMARY KEY (id);


--
-- TOC entry 3283 (class 2606 OID 24968)
-- Name: Servis_Firmasi  Servis_Firmasi _pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Servis_Firmasi "
    ADD CONSTRAINT "Servis_Firmasi _pkey" PRIMARY KEY (id);


--
-- TOC entry 3285 (class 2606 OID 24970)
-- Name: Servis_Firmasi  Servis_Firmasi _telefonNo_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Servis_Firmasi "
    ADD CONSTRAINT "Servis_Firmasi _telefonNo_key" UNIQUE ("telefonNo");


--
-- TOC entry 3287 (class 2606 OID 24972)
-- Name: Servis_Firmasi  Servis_Firmasi _vergiNo_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Servis_Firmasi "
    ADD CONSTRAINT "Servis_Firmasi _vergiNo_key" UNIQUE ("vergiNo");


--
-- TOC entry 3291 (class 2606 OID 24974)
-- Name: Servis_Gecmis Servis_Gecmis_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Servis_Gecmis"
    ADD CONSTRAINT "Servis_Gecmis_pkey" PRIMARY KEY (id);


--
-- TOC entry 3295 (class 2606 OID 24976)
-- Name: Sigorta_Firma Sigorta_Firma_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sigorta_Firma"
    ADD CONSTRAINT "Sigorta_Firma_pkey" PRIMARY KEY (id);


--
-- TOC entry 3297 (class 2606 OID 24978)
-- Name: Sigorta_Firma Sigorta_Firma_telefonNo_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sigorta_Firma"
    ADD CONSTRAINT "Sigorta_Firma_telefonNo_key" UNIQUE ("telefonNo");


--
-- TOC entry 3301 (class 2606 OID 24980)
-- Name: Sigorta_Police Sigorta_Police_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sigorta_Police"
    ADD CONSTRAINT "Sigorta_Police_pkey" PRIMARY KEY (id);


--
-- TOC entry 3303 (class 2606 OID 24982)
-- Name: Sigorta_Police Sigorta_Police_policeNo_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sigorta_Police"
    ADD CONSTRAINT "Sigorta_Police_policeNo_key" UNIQUE ("policeNo");


--
-- TOC entry 3307 (class 2606 OID 24984)
-- Name: Sube Sube_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sube"
    ADD CONSTRAINT "Sube_pkey" PRIMARY KEY (id);


--
-- TOC entry 3315 (class 2606 OID 24986)
-- Name: musteri musteri_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.musteri
    ADD CONSTRAINT musteri_pkey PRIMARY KEY (id);


--
-- TOC entry 3257 (class 2606 OID 24988)
-- Name: Ceza unique_Ceza_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ceza"
    ADD CONSTRAINT "unique_Ceza_id" UNIQUE (id);


--
-- TOC entry 3261 (class 2606 OID 24990)
-- Name: Fatura unique_Fatura_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Fatura"
    ADD CONSTRAINT "unique_Fatura_id" UNIQUE (id);


--
-- TOC entry 3265 (class 2606 OID 24992)
-- Name: Filo unique_Filo_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Filo"
    ADD CONSTRAINT "unique_Filo_id" UNIQUE (id);


--
-- TOC entry 3269 (class 2606 OID 24994)
-- Name: Kiralama unique_Kiralama_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Kiralama"
    ADD CONSTRAINT "unique_Kiralama_id" UNIQUE (id);


--
-- TOC entry 3281 (class 2606 OID 24996)
-- Name: Personal unique_Personal_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Personal"
    ADD CONSTRAINT "unique_Personal_id" UNIQUE (id);


--
-- TOC entry 3289 (class 2606 OID 24998)
-- Name: Servis_Firmasi  unique_Servis_Firmasi _id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Servis_Firmasi "
    ADD CONSTRAINT "unique_Servis_Firmasi _id" UNIQUE (id);


--
-- TOC entry 3293 (class 2606 OID 25000)
-- Name: Servis_Gecmis unique_Servis_Gecmis_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Servis_Gecmis"
    ADD CONSTRAINT "unique_Servis_Gecmis_id" UNIQUE (id);


--
-- TOC entry 3299 (class 2606 OID 25002)
-- Name: Sigorta_Firma unique_Sigorta_Firma_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sigorta_Firma"
    ADD CONSTRAINT "unique_Sigorta_Firma_id" UNIQUE (id);


--
-- TOC entry 3305 (class 2606 OID 25004)
-- Name: Sigorta_Police unique_Sigorta_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sigorta_Police"
    ADD CONSTRAINT "unique_Sigorta_id" UNIQUE (id);


--
-- TOC entry 3243 (class 2606 OID 25006)
-- Name: Adres unique_adres_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Adres"
    ADD CONSTRAINT unique_adres_id UNIQUE (id);


--
-- TOC entry 3251 (class 2606 OID 25008)
-- Name: Araba unique_araba_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Araba"
    ADD CONSTRAINT unique_araba_id UNIQUE (id);


--
-- TOC entry 3311 (class 2606 OID 25010)
-- Name: kisi unique_kisi_TC; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kisi
    ADD CONSTRAINT "unique_kisi_TC" UNIQUE ("TC");


--
-- TOC entry 3313 (class 2606 OID 25012)
-- Name: kisi unique_kisi_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kisi
    ADD CONSTRAINT unique_kisi_id PRIMARY KEY (id);


--
-- TOC entry 3273 (class 2606 OID 25014)
-- Name: OdemeTipi unique_odemeTipi_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OdemeTipi"
    ADD CONSTRAINT "unique_odemeTipi_id" UNIQUE (id);


--
-- TOC entry 3309 (class 2606 OID 25016)
-- Name: Sube unique_ofis_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sube"
    ADD CONSTRAINT unique_ofis_id UNIQUE (id);


--
-- TOC entry 3277 (class 2606 OID 25018)
-- Name: arabaOzellikler unique_ozellikler_id ; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."arabaOzellikler"
    ADD CONSTRAINT "unique_ozellikler_id " UNIQUE ("id ");


--
-- TOC entry 3333 (class 2606 OID 25019)
-- Name: kisi adresKisi; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kisi
    ADD CONSTRAINT "adresKisi" FOREIGN KEY ("adresId") REFERENCES public."Adres"(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3326 (class 2606 OID 25024)
-- Name: Servis_Firmasi  adresServis; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Servis_Firmasi "
    ADD CONSTRAINT "adresServis" FOREIGN KEY ("adresId") REFERENCES public."Adres"(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3329 (class 2606 OID 25029)
-- Name: Sigorta_Firma adresSigortaFirmasi; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sigorta_Firma"
    ADD CONSTRAINT "adresSigortaFirmasi" FOREIGN KEY ("adresId") REFERENCES public."Adres"(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3332 (class 2606 OID 25034)
-- Name: Sube adresSube; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sube"
    ADD CONSTRAINT "adresSube" FOREIGN KEY ("adresId") REFERENCES public."Adres"(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3319 (class 2606 OID 25039)
-- Name: Filo arabaFilo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Filo"
    ADD CONSTRAINT "arabaFilo" FOREIGN KEY ("arabaId") REFERENCES public."Araba"(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3320 (class 2606 OID 25044)
-- Name: Kiralama arabaKiralama; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Kiralama"
    ADD CONSTRAINT "arabaKiralama" FOREIGN KEY ("arabaId") REFERENCES public."Araba"(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3323 (class 2606 OID 25049)
-- Name: arabaOzellikler arabaOzellikler; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."arabaOzellikler"
    ADD CONSTRAINT "arabaOzellikler" FOREIGN KEY ("arabaId") REFERENCES public."Araba"(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3327 (class 2606 OID 25054)
-- Name: Servis_Gecmis arabaServisGecmis; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Servis_Gecmis"
    ADD CONSTRAINT "arabaServisGecmis" FOREIGN KEY ("arabaId") REFERENCES public."Araba"(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3330 (class 2606 OID 25059)
-- Name: Sigorta_Police arabaSigortaPolice; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sigorta_Police"
    ADD CONSTRAINT "arabaSigortaPolice" FOREIGN KEY ("arabaId") REFERENCES public."Araba"(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3328 (class 2606 OID 25064)
-- Name: Servis_Gecmis firmaServisGecmis; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Servis_Gecmis"
    ADD CONSTRAINT "firmaServisGecmis" FOREIGN KEY ("firmaId") REFERENCES public."Servis_Firmasi "(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3316 (class 2606 OID 25069)
-- Name: Ceza kiralamaCeza; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ceza"
    ADD CONSTRAINT "kiralamaCeza" FOREIGN KEY ("kiralamaId") REFERENCES public."Kiralama"(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3317 (class 2606 OID 25074)
-- Name: Fatura kiralamaFatura; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Fatura"
    ADD CONSTRAINT "kiralamaFatura" FOREIGN KEY ("kiralamaId") REFERENCES public."Kiralama"(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3334 (class 2606 OID 25079)
-- Name: musteri kisiMusteri; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.musteri
    ADD CONSTRAINT "kisiMusteri" FOREIGN KEY ("kisiId") REFERENCES public.kisi(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3324 (class 2606 OID 25084)
-- Name: Personal kisiPersonal; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Personal"
    ADD CONSTRAINT "kisiPersonal" FOREIGN KEY ("kisiId") REFERENCES public.kisi(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3321 (class 2606 OID 25089)
-- Name: Kiralama musteriKiralama; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Kiralama"
    ADD CONSTRAINT "musteriKiralama" FOREIGN KEY ("musteriId") REFERENCES public.musteri(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3318 (class 2606 OID 25094)
-- Name: Fatura odemeTipiFatura; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Fatura"
    ADD CONSTRAINT "odemeTipiFatura" FOREIGN KEY ("odemeTipId") REFERENCES public."OdemeTipi"(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3322 (class 2606 OID 25099)
-- Name: Kiralama personalKiralama; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Kiralama"
    ADD CONSTRAINT "personalKiralama" FOREIGN KEY ("PersonalId") REFERENCES public."Personal"(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3331 (class 2606 OID 25104)
-- Name: Sigorta_Police sigortaFirmaPolice; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sigorta_Police"
    ADD CONSTRAINT "sigortaFirmaPolice" FOREIGN KEY ("sigortaFirmaId") REFERENCES public."Sigorta_Firma"(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3325 (class 2606 OID 25109)
-- Name: Personal subePersonal; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Personal"
    ADD CONSTRAINT "subePersonal" FOREIGN KEY ("subeId") REFERENCES public."Sube"(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


-- Completed on 2022-08-28 23:48:33

--
-- PostgreSQL database dump complete
--

